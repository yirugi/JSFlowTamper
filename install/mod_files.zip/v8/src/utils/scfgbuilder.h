#ifndef V8_UTILS_SCFGBUILDER_H_
#define V8_UTILS_SCFGBUILDER_H_

#include "src/ast/ast.h"
#include "src/parsing/parse-info.h"
#include "src/codegen/unoptimized-compilation-info.h"

#include <vector>
#include <string>

namespace v8 {
namespace internal {

using namespace std;

class SimplifiedBasicBlock {
public:
	SimplifiedBasicBlock();

	enum Control {
		Control_None,
		Control_Goto,
		Control_If,
		Control_Conditional,
		Control_Switch,
		Control_SwitchLabel,
		Control_TryCatch,
		Control_TryFinally,
		Control_End,
	};

	string id;
	vector<Statement*> statements;
	vector<SimplifiedBasicBlock*> predecessors;
	vector<SimplifiedBasicBlock*> successors;
	Control control;
	Statement* control_stmt;
};

class SimplifiedCFG {
public:
	SimplifiedCFG();
	~SimplifiedCFG();

	int function_id;
	int script_id;
	string source_url;
	string fname;
	string fuid() { return std::to_string(script_id) + "|" + std::to_string(function_id); }
	vector<SimplifiedBasicBlock*> sbbs;
	SimplifiedBasicBlock* start;
	SimplifiedBasicBlock* end;
	SimplifiedBasicBlock* cur;
	vector<string> trace_call_sbb_ids;

};

class SimplifiedICFG {
public:

};


class SCFGBuilder final : public AstVisitor<SCFGBuilder> {
public:
	explicit SCFGBuilder(Isolate* isolate, UnoptimizedCompilationInfo* info);
	bool run(FunctionLiteral* function);
	void Print();
	void PrintAsJson();
	void buildSCFG(ZonePtrList<Statement>* statements);
	SimplifiedBasicBlock* createNewSBB(bool change_cur);
	void connectSBB(SimplifiedBasicBlock* sbb1, SimplifiedBasicBlock* sbb2);
	void disconnectSBB(SimplifiedBasicBlock* sbb1, SimplifiedBasicBlock* sbb2);
	void AddStatementToCurSBB(AstNode*, bool);
	bool checkSkipAdding(AstNode*);
	string fetchSBBId();
	void removeEmptyBlock();
	void removeErrorBlock();
	SimplifiedBasicBlock* createBranchAndVisit (SimplifiedBasicBlock* sbb_control, SimplifiedBasicBlock* sbb_merge, AstNode* visit_node);



	SimplifiedCFG scfg;
	UnoptimizedCompilationInfo* comp_info;
	int cur_sbb_id;
	vector<int> switch_break_list;
	vector<SimplifiedBasicBlock*> tryfin_info;




  // Individual nodes
#define DECLARE_VISIT(type) void Visit##type(type* node);
  AST_NODE_LIST(DECLARE_VISIT)
#undef DECLARE_VISIT

private:
    Isolate* isolate_;
	void VisitStatements(ZonePtrList<Statement>* statements);
	DEFINE_AST_VISITOR_SUBCLASS_MEMBERS();


};


}
}

#endif /* V8_UTILS_SCFGBUILDER_H_ */
