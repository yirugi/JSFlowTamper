#ifndef V8_UTILS_MYUTILS_H_
#define V8_UTILS_MYUTILS_H_

#include "src/ast/ast.h"
#include "src/parsing/parse-info.h"
#include "src/codegen/unoptimized-compilation-info.h"

#include <vector>
#include <string>



namespace v8 {
namespace internal {

using namespace std;

extern int confuzz_count;
extern bool FLAG_v8mod_trace;
extern bool FLAG_v8mod_cfmod;
extern bool FLAG_v8mod_rename;
extern bool FLAG_v8mod_stat;

extern map<int, double> statScript;
extern int statFuncCnt;
extern int statBranchCnt;
extern double statInterTime;
extern int statInterCnt;
extern double statTraceTime;

enum struct CFModType{
	None,
	Disable,
	Switch,
	Repeat
};

struct CFModItem {
	int pos;
	int branch;
	CFModType mod_type; //0:nothing, 1:disable, 2:switch, 3:repeat
	int optional;
};






class AstCallFinder final : public AstVisitor<AstCallFinder> {
public:
	explicit AstCallFinder(Isolate* isolate);
	bool findAndRemoveFromList(FunctionLiteral* function, vector<int>* offsets, vector<int>* ret_offsets);
	void VisitStatements(ZoneList<Statement*>* statements);

	vector<int>* trace_offsets;
	vector<int>* found_offsets;
	Isolate* isolate_;




	// Individual nodes
#define DECLARE_VISIT(type) void Visit##type(type* node);
  AST_NODE_LIST(DECLARE_VISIT)
#undef DECLARE_VISIT

private:
	DEFINE_AST_VISITOR_SUBCLASS_MEMBERS();

};




class Myutils {

public:
	//   static string GetPosition(AstNode* node, Script* script);
	  static string GetPosition(AstNode* node, Handle<Script> script);
	//   static string GetSourceUrl(Script* script);
	  static string GetSourceUrl(Handle<Script> script);
	  static void LoadModConfig(ParseInfo* info);
	  static bool CheckCFMod(ParseInfo* info, AstNode* node, CFModItem* cfmod);
	  static bool IsJump(AstNode* node);
	  static void RenameScript(ParseInfo* info);
	  static void PrintStat();
	  static void ResetStat();
	  static string GetFunctionName(UnoptimizedCompilationInfo* info);  
	  static void addStatTraceTime(double time);

private:
}; // class Myutils


class MyGlobalStorage {
  public:
	vector<vector<int>> traceOffsetsList;
	vector<string> traceSrcUrlList;
	vector<vector<CFModItem>> cfmodList;

	map<int, double> statScript;
};
// class MyGlobalStorage

extern MyGlobalStorage* myGlobalStorage;

}
}

#endif /* V8_UTILS_MYUTILS_H_ */
