#include "src/utils/myutils.h"

#include "src/objects/objects-inl.h"
#include "src/parsing/parse-info.h"
#include "src/ast/ast.h"
#include "src/codegen/unoptimized-compilation-info.h"

#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include <cstdlib>


namespace v8 {
namespace internal {

using namespace std;

/*
 * global varibles
 */

bool FLAG_v8mod_trace = false;
bool FLAG_v8mod_cfmod = false;
bool FLAG_v8mod_rename = false;
bool FLAG_v8mod_stat = false;

bool isConfigLoaded = false;

int statFuncCnt = 0;
int statBranchCnt = 0;
double statInterTime = 0.0;
int statInterCnt = 0;
double statTraceTime = 0.0;

MyGlobalStorage* myGlobalStorage = new MyGlobalStorage();


/* ==================================================================================================================
 * AstCallFinder
 ================================================================================================================== */

AstCallFinder::AstCallFinder(Isolate* isolate) {
	InitializeAstVisitor(isolate);
	isolate_ = isolate;
}


bool AstCallFinder::findAndRemoveFromList(FunctionLiteral* function, vector<int>* offsets, vector<int>* ret_offsets) {
	if(offsets == nullptr || offsets->size() == 0)
		return false;

	trace_offsets = offsets;
	found_offsets = ret_offsets;
	VisitStatements(function->body());

	return (found_offsets->size() != 0);

}


void AstCallFinder::VisitStatements(ZonePtrList<Statement>* statements) {
  for (int i = 0; i < statements->length(); i++) {
  		Statement* stmt = statements->at(i);
  		Visit(stmt);
  }
}

void AstCallFinder::VisitCall(Call* node) {

	for(unsigned i=0;i<trace_offsets->size();i++){
		int offset = trace_offsets->at(i);
		if(offset == node->position()){
			found_offsets->push_back(offset);
			trace_offsets->erase(trace_offsets->begin() + i);
			break;
		}
	}

	const ZonePtrList<Expression>* args = node->arguments();
	for (int i = 0; i < static_cast<int>(args->length()); i++) {
		Visit(args->at(i));
	}
	Visit(node->expression());
}



void AstCallFinder::VisitIfStatement(IfStatement* node) {
  Visit(node->condition());
  Visit(node->then_statement());
  if (node->HasElseStatement()) {
  		Visit(node->else_statement());
  }
}

void AstCallFinder::VisitConditional(Conditional* node) {
  Visit(node->condition());
  Visit(node->then_expression());
  	Visit(node->else_expression());
}

void AstCallFinder::VisitSwitchStatement(SwitchStatement* node) {
	Visit(node->tag());

	for (CaseClause* clause : *node->cases()) {
		if (clause->is_default()) {
			VisitStatements(clause->statements());
		} else {
			Visit(clause->label());
			VisitStatements(clause->statements());
		}
	}
}





void AstCallFinder::VisitBlock(Block* node) {
  VisitStatements(node->statements());
}

void AstCallFinder::VisitExpressionStatement(ExpressionStatement* node) {
  Visit(node->expression());
}

void AstCallFinder::VisitContinueStatement(ContinueStatement* node) {
}


void AstCallFinder::VisitBreakStatement(BreakStatement* node) {
}


void AstCallFinder::VisitReturnStatement(ReturnStatement* node) {
	Visit(node->expression());
}


void AstCallFinder::VisitVariableDeclaration(VariableDeclaration* node) {
}


void AstCallFinder::VisitFunctionDeclaration(FunctionDeclaration* node) {
}





void AstCallFinder::VisitEmptyStatement(EmptyStatement* node) {
}


void AstCallFinder::VisitSloppyBlockFunctionStatement(
    SloppyBlockFunctionStatement* node) {
  Visit(node->statement());
}

void AstCallFinder::VisitWithStatement(WithStatement* node) {
  Visit(node->expression());
  Visit(node->statement());
}

void AstCallFinder::VisitDoWhileStatement(DoWhileStatement* node) {
  Visit(node->body());
  Visit(node->cond());
}


void AstCallFinder::VisitWhileStatement(WhileStatement* node) {
  Visit(node->cond());
  Visit(node->body());
}


void AstCallFinder::VisitForStatement(ForStatement* node) {
  if (node->init()) Visit(node->init());
  if (node->cond()) Visit(node->cond());
  Visit(node->body());
  if (node->next()) Visit(node->next());
}


void AstCallFinder::VisitForInStatement(ForInStatement* node) {
  Visit(node->each());
  Visit(node->subject());
  Visit(node->body());
}


void AstCallFinder::VisitForOfStatement(ForOfStatement* node) {
  Visit(node->each());
  Visit(node->subject());
  Visit(node->body());
}


void AstCallFinder::VisitTryCatchStatement(TryCatchStatement* node) {
  Visit(node->try_block());
  Visit(node->catch_block());
}

void AstCallFinder::VisitTryFinallyStatement(TryFinallyStatement* node) {
  Visit(node->try_block());
  Visit(node->finally_block());
}

void AstCallFinder::VisitDebuggerStatement(DebuggerStatement* node) {
}


void AstCallFinder::VisitFunctionLiteral(FunctionLiteral* node) {
}


void AstCallFinder::VisitClassLiteral(ClassLiteral* node) {
  if (node->extends() != nullptr) {
    Visit(node->extends());
  }
  for (int i = 0; i < node->public_members()->length(); i++) {
    Visit(node->public_members()->at(i)->value());
  }
  for (int i = 0; i < node->private_members()->length(); i++) {
    Visit(node->private_members()->at(i)->value());
  }
}

void AstCallFinder::VisitInitializeClassMembersStatement(
    InitializeClassMembersStatement* node) {
}

void AstCallFinder::VisitNativeFunctionLiteral(NativeFunctionLiteral* node) {
}

void AstCallFinder::VisitLiteral(Literal* node) {
}

void AstCallFinder::VisitRegExpLiteral(RegExpLiteral* node) {
}


void AstCallFinder::VisitObjectLiteral(ObjectLiteral* node) {
}


void AstCallFinder::VisitArrayLiteral(ArrayLiteral* node) {
  if (node->values()->length() > 0) {
    for (int i = 0; i < node->values()->length(); i++) {
      Visit(node->values()->at(i));
    }
  }
}


void AstCallFinder::VisitVariableProxy(VariableProxy* node) {
}


void AstCallFinder::VisitAssignment(Assignment* node) {
  Visit(node->target());
  Visit(node->value());
}

void AstCallFinder::VisitCompoundAssignment(CompoundAssignment* node) {
  VisitAssignment(node);
}

void AstCallFinder::VisitYield(Yield* node) {
  Visit(node->expression());
}

void AstCallFinder::VisitYieldStar(YieldStar* node) {
  Visit(node->expression());
}

void AstCallFinder::VisitAwait(Await* node) {
  Visit(node->expression());
}

void AstCallFinder::VisitThrow(Throw* node) {
  Visit(node->exception());
}


void AstCallFinder::VisitProperty(Property* node) {
  Visit(node->obj());
  Literal* literal = node->key()->AsLiteral();
	AllowHandleAllocation handles;
  if (literal != nullptr &&
      literal->BuildValue(isolate_)->IsInternalizedString()) {
  } else {
	Visit(node->key());
  }
}

void AstCallFinder::VisitCallNew(CallNew* node) {
  Visit(node->expression());
}


void AstCallFinder::VisitCallRuntime(CallRuntime* node) {
}


void AstCallFinder::VisitUnaryOperation(UnaryOperation* node) {
  Visit(node->expression());
}


void AstCallFinder::VisitCountOperation(CountOperation* node) {
  Visit(node->expression());
}


void AstCallFinder::VisitBinaryOperation(BinaryOperation* node) {
		Visit(node->left());
		Visit(node->right());
}

void AstCallFinder::VisitNaryOperation(NaryOperation* node) {
  Visit(node->first());
  for (size_t i = 0; i < node->subsequent_length(); ++i) {
    Visit(node->subsequent(i));
  }
}

void AstCallFinder::VisitCompareOperation(CompareOperation* node) {
  Visit(node->left());
  Visit(node->right());
}


void AstCallFinder::VisitSpread(Spread* node) {
  Visit(node->expression());
}


void AstCallFinder::VisitEmptyParentheses(EmptyParentheses* node) {
}


void AstCallFinder::VisitGetTemplateObject(GetTemplateObject* node) {
}

void AstCallFinder::VisitImportCallExpression(ImportCallExpression* node) {
  Visit(node->argument());
}

void AstCallFinder::VisitThisExpression(ThisExpression* node) {
}


void AstCallFinder::VisitSuperPropertyReference(SuperPropertyReference* node) {
}


void AstCallFinder::VisitSuperCallReference(SuperCallReference* node) {
}

/* new functions */
void AstCallFinder::VisitOptionalChain(OptionalChain* node) {
  Visit(node->expression());
}
void AstCallFinder::VisitTemplateLiteral(TemplateLiteral* node) {
  for (Expression* substitution : *node->substitutions()) {
    Visit(substitution);
  }
}



/* AstCallFinder end */



/*==================================================================================================================
 * MyUtils
 ==================================================================================================================*/

string Myutils::GetPosition(AstNode* node, Handle<Script> script) {
  // if (script->type() != Script::TYPE_WASM) Script::InitLineEnds(script);
  Script::PositionInfo pos;
  script->GetPositionInfo(node->position(), &pos, Script::WITH_OFFSET);
  std::string position =
      std::to_string(pos.line + 1) + ":" + std::to_string(pos.column + 1);
  return position;
}

// string Myutils::GetPosition(AstNode* node, Script* script) {
//   Script::PositionInfo pos;
//   script->GetPositionInfo(node->position(), &pos, Script::WITH_OFFSET);
//   std::string position =
//       std::to_string(pos.line + 1) + ":" + std::to_string(pos.column + 1);
//   return position;
// }

string Myutils::GetSourceUrl(Handle<Script> script) {
  if (!script.is_null() && script->GetNameOrSourceURL().IsString()) {    
    return String::cast(script->GetNameOrSourceURL()).ToCString().get();
  } else
    return "";
}

// string Myutils::GetPosition(AstNode* node, Handle<Script> script) {
// 	Script* sc = *script.location();
// 	return GetPosition(node, sc);
// }

// string Myutils::GetPosition(AstNode* node, Script* script) {
// 	Script::PositionInfo pos;
// 	script->GetPositionInfo(node->position(), &pos, Script::WITH_OFFSET);
// 	std::string position = std::to_string(pos.line + 1) + ":" + std::to_string(pos.column + 1);
// 	return position;
// }

// string Myutils::GetSourceUrl(Script* script){
// 	if (script != nullptr && script->GetNameOrSourceURL()->IsString()) {
// 		String* sourceUrl = String::cast(script->GetNameOrSourceURL());
// 		std::unique_ptr<char[]> sourceUrl_chars = sourceUrl->ToCString();
// 		return sourceUrl_chars.get();
// 	} else
// 		return "";
// }

// string Myutils::GetSourceUrl(Handle<Script> script){
// 	if(script.location() == nullptr)
// 		return "";
// 	Script* sc = *script.location();
// 	return GetSourceUrl(sc);
// }


void Myutils::LoadModConfig(ParseInfo* info){

  if(!isConfigLoaded) {
  		isConfigLoaded = true;
    // string filePath = "/Users/yirugi/research/jsproject/v8mod_cfg/v8mod.cfg";
		string filePath = "v8mod.cfg";

		// system("pwd > /tmp/pp");

		ifstream openFile(filePath.data());
		if( openFile.is_open() ){
			string line;
			getline(openFile, line);
			FLAG_v8mod_trace = line.substr(6,1)=="1"?true:false;
			getline(openFile, line);
			FLAG_v8mod_cfmod = line.substr(6,1)=="1"?true:false;
			getline(openFile, line);
			FLAG_v8mod_rename = line.substr(7,1)=="1"?true:false;
			getline(openFile, line);
			FLAG_v8mod_stat = line.substr(5,1)=="1"?true:false;

			// read config data
			int turn = 0;
			while(getline(openFile, line)){
				if(line.length() == 0 || line.substr(0,1) == "#")
					continue;

				//cout << turn << ", " << line << "\n";
				switch(turn){
				case 0: //source url
					{
						myGlobalStorage->traceSrcUrlList.push_back(line);
						break;
					}
				case 1: // trace offset
					{
						vector<int> tracePosList;
						if(line == "none"){
							myGlobalStorage->traceOffsetsList.push_back(tracePosList);
							break;
						}
						//split by ','
						istringstream tokenStream(line);
						string token;
						while (getline(tokenStream, token, ',')){
							tracePosList.push_back(std::stoi(token));
						}
						myGlobalStorage->traceOffsetsList.push_back(tracePosList);
						break;
					}
				case 2: //cfmod data
					{
						vector<CFModItem> cfmods;
						if(line == "none"){
							myGlobalStorage->cfmodList.push_back(cfmods);
							break;
						}
						istringstream tokenStream(line);
						string token;

						while (getline(tokenStream, token, ',')){
							istringstream tokenStream2(token);
							string token2;
							int value[4];
							int index=0;
							while (getline(tokenStream2, token2, ':')){
								value[index] = std::stoi(token2);
								if(index == 3) break; // for safety
								index++;
							}
							CFModItem item;
							item.pos = value[0];
							item.branch = value[1];
							item.mod_type = (CFModType)value[2];
							item.optional = value[3];
							cfmods.push_back(item);
						}
						myGlobalStorage->cfmodList.push_back(cfmods);
						break;
					}
				}

				turn = (turn+1) % 3;

			} // end config file load
			openFile.close();
			/*
		  for(auto item:myGlobalStorage->traceSrcUrlList){
		  		cout << item << "\n";
		  }

			for(auto cfmods: myGlobalStorage->cfmodList){
				for(auto item:cfmods){
					cout << item.pos << "," << item.optional << "," <<item.branch << "," << (int)(item.mod_type) << "\n";
				}
			}

			cout << flush;
			*/

		} else {
			cout << "trace file open failure\n";
			return;
		}
  }



  // assign proper one
  if(!FLAG_v8mod_trace && !FLAG_v8mod_cfmod)
  		return;

	string sourceURL = Myutils::GetSourceUrl(info->script());

	for(vector<int>::size_type i = 0; i != myGlobalStorage->traceSrcUrlList.size(); i++) {

			if(myGlobalStorage->traceSrcUrlList[i] == sourceURL){
				if(FLAG_v8mod_trace)
					info->traceOffsets = &myGlobalStorage->traceOffsetsList.at(i);
				if(FLAG_v8mod_cfmod)
					info->cfmods = &myGlobalStorage->cfmodList.at(i);

				//cout << "TracePosList loaded : size = " << info->traceOffsets->size() << ", sourceURL = " << sourceURL << "\n";
				info->is_v8mod_script = true;
				break;
			}
	}


}

bool Myutils::CheckCFMod(ParseInfo* info, AstNode* node, CFModItem* cfmod){
  if(info->is_v8mod_script && FLAG_v8mod_cfmod){
  		for(unsigned i=0; i<info->cfmods->size(); i++){
  			CFModItem item =  info->cfmods->at(i);
  			//cout << cfmod.pos << "\n";
  			if(node->position() == item.pos){
  				cfmod->pos = item.pos;
  				cfmod->branch = item.branch;
  				cfmod->mod_type = item.mod_type;
  				cfmod->optional = item.optional;
  				//info->cfmods->erase(info->cfmods->begin() + i);
  				return true;
  			}
  		}
  }
  return false;
}

bool Myutils::IsJump(AstNode* node){
	if(node->node_type() == 13 || node->node_type() == 14 || node->node_type() == 15)
		return true;
	else
		return false;
}

void Myutils::RenameScript(ParseInfo* info)
{
	if(info->script().location() == nullptr )
		return;

  string script_type = "";
	
  if(info->flags().is_eval()){
		script_type = "eval";		
  } else if(Myutils::GetSourceUrl(info->script()) == ""){		
		script_type = "noname";
	}	

  if(script_type != ""){		
		String source = String::cast(info->script()->source());		
		string source_str = source.ToCString().get();
		size_t sizet_hash = std::hash<std::string>{}(source_str);
		string hash_str = std::to_string(sizet_hash);
		hash_str = script_type + hash_str;

		AllowHeapAllocation allocation;
		AllowHandleAllocation handles;
		Handle<String> hs = Isolate::Current()->factory()->InternalizeUtf8String(hash_str.c_str());
		info->script()->set_name(*hs);
  }
}

string Myutils::GetFunctionName(UnoptimizedCompilationInfo* info)
{
	return info->literal()->GetDebugName().get();
}

void Myutils::PrintStat()
{
	double totSize = 0.0;
	for(auto it = myGlobalStorage->statScript.begin(); it != myGlobalStorage->statScript.end(); it++){
			totSize += it->second;
	}

	cout << ">>STAT:" << totSize << "," << myGlobalStorage->statScript.size() << "," << statFuncCnt  <<"," <<  statBranchCnt << ","<< statInterTime / (double)statInterCnt << "," << statInterCnt << ","
			<< statTraceTime << "\n";
	cout << std::flush;
}

void Myutils::ResetStat()
{
	myGlobalStorage->statScript.clear();
	statFuncCnt = 0;
	statBranchCnt = 0;
	statInterTime = 0.0;
	statInterCnt = 0;
	statTraceTime = 0.0;
}

void Myutils::addStatTraceTime(double time)
{
	statTraceTime += time;
}






}
}  // namespace v8


