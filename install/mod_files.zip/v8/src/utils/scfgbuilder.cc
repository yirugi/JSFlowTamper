#include "src/utils/scfgbuilder.h"

#include "src/utils/myutils.h"
#include "src/objects-inl.h"
#include "src/parsing/parse-info.h"
#include "src/ast/ast.h"
#include "src/compilation-info.h"

#include <string>
#include <iostream>


namespace v8 {
namespace internal {
using namespace std;

/* ==================================================================================================================
 * SimplifiedBasicBlock
 ================================================================================================================== */
SimplifiedBasicBlock::SimplifiedBasicBlock()
    : control(Control_None),
			control_stmt(nullptr)
	{

}

/* SimplifiedBasicBlock - End */

/* ==================================================================================================================
 * SimplifiedCFG
 ==================================================================================================================*/
SimplifiedCFG::SimplifiedCFG()
		:	function_id(-1),
			script_id(-1),
			start(nullptr),
			cur(nullptr) {
	end = new SimplifiedBasicBlock();
}

SimplifiedCFG::~SimplifiedCFG() {
	//delete all sbb
	for(auto sbb: sbbs) {
		delete sbb;
	}
	//delete end sbb
	//delete end;
}

/* SimplifiedCFG - End */


/* ==================================================================================================================
 * SCFGBuilder
 ================================================================================================================== */

SCFGBuilder::SCFGBuilder(Isolate* isolate, CompilationInfo* info) {
	InitializeAstVisitor(isolate);
	comp_info = info;
	cur_sbb_id = 0;
}


bool SCFGBuilder::run(FunctionLiteral* function) {
	// basic information
	scfg.fname = function->GetDebugName().get();
	scfg.function_id = function->start_position();
	scfg.script_id = comp_info->script()->id();
	scfg.source_url = Myutils::GetSourceUrl(comp_info->script());

	for(unsigned i=0; i<comp_info->parse_info()->traceOffsetsInThisFunction.size();i++)
		scfg.trace_call_sbb_ids.push_back("");

	SimplifiedBasicBlock* sbb = createNewSBB(true);
	scfg.start = sbb;

	VisitStatements(function->body());
	// set current node's control to end
	scfg.cur->control = SimplifiedBasicBlock::Control_End;
	//connect if not connected
	if(scfg.cur->successors.size() == 0)
		connectSBB(scfg.cur, scfg.end);

	scfg.end->id = fetchSBBId();
	scfg.sbbs.push_back(scfg.end);

	removeEmptyBlock();
	removeErrorBlock();

	//cout << "\n";
	//Print();
	PrintAsJson();
	return true;
}

string SCFGBuilder::fetchSBBId(){
	//scfg.fuid() + "|" + std::to_string(cur_sbb_id);
	string id = std::to_string(cur_sbb_id);
	cur_sbb_id++;
	return id;
}

void SCFGBuilder::PrintAsJson(){
	printf("{");
	printf("\"function_name\":\"%s\"", scfg.fname.c_str());
	printf(",\"fuid\":\"%s\"", scfg.fuid().c_str());
	printf(",\"script_id\":\"%d\"", comp_info->script()->id());
	printf(",\"function_id\":\"%d\"", scfg.function_id);
	printf(",\"source_url\":\"%s\"", scfg.source_url.c_str());
	printf(",\"trace_calls\":[");
	string tmp = "";
	for(unsigned i=0; i<scfg.trace_call_sbb_ids.size(); i++){
		string id = scfg.trace_call_sbb_ids.at(i);
		string pos = std::to_string(comp_info->parse_info()->traceOffsetsInThisFunction.at(i));
		tmp += "{\"pos\":\"" + pos + "\", \"id\":\"" + id + "\"},";
	}
	if(tmp != "")
		tmp = tmp.substr(0, tmp.size() - 1);
	printf("%s]", tmp.c_str());

	printf(",\"sbbs\":[");
	int sbb_index = 0;
	for(auto sbb: scfg.sbbs){
		printf("{");
		printf("\"id\":\"%s\"", sbb->id.c_str());
		printf(",\"control\":\"%d\"", sbb->control);
		//pred
		printf(",\"predecessors\":[");
		string tmp = "";
		for(auto pred: sbb->predecessors){
			tmp += "\"" + pred->id + "\",";
		}
		if(tmp != "")
			tmp = tmp.substr(0, tmp.size() - 1);
		printf("%s]", tmp.c_str());

		//succ
		tmp = "";
		printf(",\"successors\":[");
		for(auto succ: sbb->successors){
			tmp += "\"" + succ->id + "\",";
		}
		if(tmp != "")
			tmp = tmp.substr(0, tmp.size() - 1);
		printf("%s]", tmp.c_str());

		//statements
		printf(",\"statements\":[");
		tmp = "";
		for(auto stmt: sbb->statements){
			tmp += "{";
			//tmp += "\"position\":\"" + Myutils::GetPosition(stmt, comp_info->script()) + "\"";
			tmp += "\"position\":\"" + std::to_string(stmt->position()) + "\"";

			int node_type = (int)stmt->node_type();
			if(stmt->node_type() == AstNode::kExpressionStatement){
				node_type =  (int)((ExpressionStatement*)stmt)->expression()->node_type();
			}
			tmp += ",\"node_type\":\"" + std::to_string(node_type) + "\"";
			tmp += "},";
		}
		if(tmp != "")
			tmp = tmp.substr(0, tmp.size() - 1);
		printf("%s]", tmp.c_str());

		printf("}");
		if(sbb_index + 1 != (int)scfg.sbbs.size()){
			printf(",");
		}
		sbb_index++;
	}
	printf("]}\n");


}
void SCFGBuilder::Print(){
	/* enable only for debug mode
	cout << "\n>> SCFG for function = " << scfg.fname << " ["<< scfg.fuid() <<"]\n";
	cout << "source url = " << scfg.source_url << "\n";
	for(auto sbb: scfg.sbbs) {
		cout << "\n[NEW SBB]\n";
		for(auto stmt: sbb->statements) {
			cout << "statement at " << Myutils::GetPosition(stmt, comp_info->script()) << "," << stmt->node_type() << "\n";
			stmt->Print();
		}
	}
	*/
}

void SCFGBuilder::removeEmptyBlock(){
	vector<int> to_remove;
	for(vector<SimplifiedBasicBlock*>::size_type i = 0; i != scfg.sbbs.size() - 1; i++) {
		SimplifiedBasicBlock* sbb = scfg.sbbs.at(i);
		if(sbb->statements.size() == 0 && sbb->control != SimplifiedBasicBlock::Control_SwitchLabel){
			if(sbb->successors.size() > 1 || sbb->successors.size() == 0) //error??
				continue;
			else {
				SimplifiedBasicBlock* succ = sbb->successors.at(0);
				//cout << "cur sbb : " << i << "\n";
				vector<SimplifiedBasicBlock*> to_remove_pred;
				for(auto pred: sbb->predecessors){
					//cout << "disconn " << pred->id << "," << sbb->id << "\n";
					//disconnectSBB(pred, sbb);
					to_remove_pred.push_back(pred);
					//cout << "conn " << pred->id << "," << succ->id << "\n";
					//connectSBB(pred, succ);
					//insert instead of just connecting
					for(unsigned i=0; i < pred->successors.size(); i++){
						if(pred->successors.at(i) == sbb){
							pred->successors.insert(pred->successors.begin() + i, succ);
							break;
						}
					}

					succ->predecessors.push_back(pred);
				}
				for(auto pred: to_remove_pred)
					disconnectSBB(pred, sbb);

				//cout << "disconn " << sbb->id << "," << succ->id << "\n";
				disconnectSBB(sbb, succ);
				to_remove.push_back((int)i);
			}
		}
	}

	for(vector<int>::size_type i = 0; i != to_remove.size(); i++) {
		int index = to_remove.at(i) - (int)i;
		//cout << "removing " << scfg.sbbs.at(index)->id << "\n";
		delete scfg.sbbs.at(index);
		scfg.sbbs.erase(scfg.sbbs.begin() + index);
	}
}

void SCFGBuilder::removeErrorBlock(){
	vector<int> to_remove;
	//remove blocks have no predecessors except start block
	for(unsigned i=1;i<scfg.sbbs.size();i++){
		SimplifiedBasicBlock* sbb = scfg.sbbs.at(i);
		//cout << i << ", pred cnt = " << sbb->predecessors.size() << "\n";
		if(sbb->predecessors.size() == 0){
			for(auto succ: sbb->successors)
				disconnectSBB(sbb, succ);
			to_remove.push_back(i);
		}
	}


	for(vector<int>::size_type i = 0; i != to_remove.size(); i++) {
		int index = to_remove.at(i) - (int)i;
		delete scfg.sbbs.at(index);
		scfg.sbbs.erase(scfg.sbbs.begin() + index);
	}

}


SimplifiedBasicBlock* SCFGBuilder::createNewSBB(bool change_cur){
	SimplifiedBasicBlock* sbb = new SimplifiedBasicBlock();
	sbb->id = fetchSBBId();
	scfg.sbbs.push_back(sbb);
	if(change_cur)
			scfg.cur = sbb;
	return sbb;
}

void SCFGBuilder::connectSBB(SimplifiedBasicBlock* sbb1, SimplifiedBasicBlock* sbb2){
	sbb1->successors.push_back(sbb2);
	sbb2->predecessors.push_back(sbb1);
}

void SCFGBuilder::disconnectSBB(SimplifiedBasicBlock* sbb1, SimplifiedBasicBlock* sbb2){
	for(unsigned i=0;i<sbb1->successors.size();i++){
		if(sbb1->successors.at(i) == sbb2){
			 sbb1->successors.erase(sbb1->successors.begin() + i);
		}
	}

	for(unsigned i=0;i<sbb2->predecessors.size();i++){
		if(sbb2->predecessors.at(i) == sbb1){
			sbb2->predecessors.erase(sbb2->predecessors.begin() + i);
		}
	}
}

void SCFGBuilder::AddStatementToCurSBB(AstNode* node, bool doesCheckSkip){
	if(doesCheckSkip && checkSkipAdding(node))
			return;

	scfg.cur->statements.push_back((Statement*)node);
}

bool SCFGBuilder::checkSkipAdding(AstNode* node) {
	switch(node->node_type()){
	case 7:		//block
	case 8:		//switch
	case 9:		//expression
	case 12:		//if
	case 13:		//continue
	case 14:		//break
	case 15:		//return
	case 17:		//try-catch
	case 18:		//try-finally
	case 26:		//binary
	case 27:		//nary
	case 28:		//call
	case 34:		//conditional

		return true;
	default:
		return false;
	}

}

SimplifiedBasicBlock* SCFGBuilder::createBranchAndVisit (SimplifiedBasicBlock* sbb_control, SimplifiedBasicBlock* sbb_merge, AstNode* visit_node){
	SimplifiedBasicBlock* sbb_branch = createNewSBB(true);
	connectSBB(sbb_control, sbb_branch);
	Visit(visit_node);
	sbb_branch = scfg.cur;

	if(sbb_branch->successors.size() == 0)
		connectSBB(sbb_branch, sbb_merge);
	return sbb_branch;
}

void SCFGBuilder::VisitStatements(ZoneList<Statement*>* statements) {
  for (int i = 0; i < statements->length(); i++) {
  		Statement* stmt = statements->at(i);
  		//stmt->Print();
  		AddStatementToCurSBB(stmt, true);
  		Visit(stmt);
  		if (stmt->IsReturnStatement())
  			break;
  		/*
  		if (stmt->IsJump()){
  			Visit(stmt);
  			break;
  		} else {
  			scfg.cur->statements.push_back(stmt);
  			Visit(stmt);
  		}
  		*/
  }
}

void SCFGBuilder::VisitIfStatement(IfStatement* node) {

	//SimplifiedBasicBlock* sbb_if = scfg.cur;
  Visit(node->condition());
  AddStatementToCurSBB(node, false);

  SimplifiedBasicBlock* sbb_if = scfg.cur;
  sbb_if->control = SimplifiedBasicBlock::Control_If;
  SimplifiedBasicBlock* sbb_merge = createNewSBB(false);

  // then
  createBranchAndVisit(sbb_if, sbb_merge, node->then_statement());

  // else
  if (node->HasElseStatement()) {
  		createBranchAndVisit(sbb_if, sbb_merge, node->else_statement());
  } else {
  		connectSBB(sbb_if, sbb_merge);
  }

  scfg.cur = sbb_merge;
}

void SCFGBuilder::VisitConditional(Conditional* node) {
  Visit(node->condition());
  AddStatementToCurSBB(node, false);
  SimplifiedBasicBlock* sbb_condition = scfg.cur;
  sbb_condition->control = SimplifiedBasicBlock::Control_Conditional;
  SimplifiedBasicBlock* sbb_merge = createNewSBB(false);

  createBranchAndVisit(sbb_condition, sbb_merge, node->then_expression());
  	AddStatementToCurSBB(node->then_expression(), true);
  createBranchAndVisit(sbb_condition, sbb_merge, node->else_expression());
  	AddStatementToCurSBB(node->else_expression(), true);
  scfg.cur = sbb_merge;

  //Visit(node->then_expression());
  //Visit(node->else_expression());
}

void SCFGBuilder::VisitSwitchStatement(SwitchStatement* node) {
  Visit(node->tag());
  SimplifiedBasicBlock* sbb_switch = scfg.cur;
  sbb_switch->control = SimplifiedBasicBlock::Control_Switch;
  AddStatementToCurSBB(node, false);

  SimplifiedBasicBlock* sbb_merge = createNewSBB(false);

  //create nodes first
  vector<SimplifiedBasicBlock*> sbbs_clause;
  for (int i = 0; i < node->cases()->length(); i++) {
  		SimplifiedBasicBlock* sbb = createNewSBB(false);
  		sbbs_clause.push_back(sbb);
  }

  int default_id = -1;
  SimplifiedBasicBlock* sbb_prev_label = sbb_switch;
  for (int i = 0; i < node->cases()->length(); i++) {
      CaseClause* clause = node->cases()->at(i);
      SimplifiedBasicBlock* sbb_clause = sbbs_clause.at(i);

      if (clause->is_default()) {
      		default_id = i;
      } else {
      		SimplifiedBasicBlock* sbb_label = createNewSBB(true);
      		//connectSBB(sbb_prev_label, sbb_label);
      		connectSBB(sbb_switch, sbb_label);
      		AddStatementToCurSBB(clause->label(), true);
      		Visit(clause->label());
      		sbb_label = scfg.cur;
      		connectSBB(sbb_label, sbb_clause);
      		sbb_prev_label = sbb_label;
      		sbb_label->control = SimplifiedBasicBlock::Control_SwitchLabel;
			}


			scfg.cur = sbb_clause;


      	VisitStatements(clause->statements());
      	sbb_clause = scfg.cur;
      	if(sbb_clause->successors.size() == 0){
      		vector<int>::iterator it;
				it = find(switch_break_list.begin(), switch_break_list.end(), node->position());
				if (it != switch_break_list.end() ) { // has break
					switch_break_list.erase(it);
				connectSBB(sbb_clause, sbb_merge);
				} else { // no break. connect to the next case
					if (i + 1 >= node->cases()->length()) //if this is the last one
						connectSBB(sbb_clause, sbb_merge);
					else {
					//sbbs_clause.at(i)->control = SimplifiedBasicBlock::Control_Goto;
					connectSBB(sbb_clause, sbbs_clause.at(i+1));
					}
				}
      	}


  }
  switch_break_list.empty();

  //handle default here since default label has to be the last one
  if(default_id != -1){
  		//connectSBB(sbb_prev_label, sbbs_clause.at(default_id));
  		connectSBB(sbb_switch, sbbs_clause.at(default_id));
  } else{
  		//connectSBB(sbb_prev_label, sbb_merge);
  		connectSBB(sbb_switch, sbb_merge);
  }

  scfg.cur = sbb_merge;

}

void SCFGBuilder::VisitCall(Call* node) {
	if(comp_info->parse_info()->has_trace_call){
		std::vector<int>* traceOffsets = &comp_info->parse_info()->traceOffsetsInThisFunction;
		for(unsigned i=0;i<traceOffsets->size();i++){
			if(node->position() == traceOffsets->at(i)){
				scfg.trace_call_sbb_ids.at(i) = scfg.cur->id;
				break;
			}
		}
	}
/*
	if(comp_info->parse_info()->has_trace_call){
		std::vector<int>* traceOffsets = &comp_info->parse_info()->traceOffsetsInThisFunction;
		for(unsigned i=0;i<traceOffsets->size();i++){
			if(node->position() == traceOffsets->at(i)){

				break;
			}
		}
	}
*/
	ZoneList<Expression*>* args = node->arguments();
	for (int i = 0; i < static_cast<int>(args->length()); i++) {
		Visit(args->at(i));
	}
	Visit(node->expression());
	AddStatementToCurSBB(node, false);

}



void SCFGBuilder::VisitBlock(Block* node) {
  VisitStatements(node->statements());
}

void SCFGBuilder::VisitExpressionStatement(ExpressionStatement* node) {
	AddStatementToCurSBB(node->expression(), true);
  Visit(node->expression());
}

void SCFGBuilder::VisitContinueStatement(ContinueStatement* node) {
	AddStatementToCurSBB(node, false);
}


void SCFGBuilder::VisitBreakStatement(BreakStatement* node) {
	if(node->target()->IsSwitchStatement()){
		switch_break_list.push_back(node->target()->position());
	}
	AddStatementToCurSBB(node, false);
}


void SCFGBuilder::VisitReturnStatement(ReturnStatement* node) {
	Visit(node->expression());

	if(node->position() != -1){
		AddStatementToCurSBB(node, false);
	}
	if(tryfin_info.size() != 0){
		//connect to finally block
		SimplifiedBasicBlock* sbb_fin = tryfin_info.back();
		//remove all successors
		for(auto succ: scfg.cur->successors){
			disconnectSBB(scfg.cur, succ);
		}
		connectSBB(scfg.cur, sbb_fin);
		scfg.cur->control = SimplifiedBasicBlock::Control_Goto;

	} else {
		//remove all successors
		for(auto succ: scfg.cur->successors){
			cout << scfg.cur->id << "," << succ->id << "\n";
			disconnectSBB(scfg.cur, succ);
		}
		connectSBB(scfg.cur, scfg.end);
		scfg.cur->control = SimplifiedBasicBlock::Control_Goto;
	}


}


void SCFGBuilder::VisitVariableDeclaration(VariableDeclaration* node) {
}


void SCFGBuilder::VisitFunctionDeclaration(FunctionDeclaration* node) {
}





void SCFGBuilder::VisitEmptyStatement(EmptyStatement* node) {
}


void SCFGBuilder::VisitSloppyBlockFunctionStatement(
    SloppyBlockFunctionStatement* node) {
  Visit(node->statement());
}








void SCFGBuilder::VisitWithStatement(WithStatement* node) {
  Visit(node->expression());
  Visit(node->statement());
}





void SCFGBuilder::VisitDoWhileStatement(DoWhileStatement* node) {
  Visit(node->body());
  Visit(node->cond());
}


void SCFGBuilder::VisitWhileStatement(WhileStatement* node) {
  Visit(node->cond());
  Visit(node->body());
}


void SCFGBuilder::VisitForStatement(ForStatement* node) {
  if (node->init()) Visit(node->init());
  if (node->cond()) Visit(node->cond());
  Visit(node->body());
  if (node->next()) Visit(node->next());
}


void SCFGBuilder::VisitForInStatement(ForInStatement* node) {
  Visit(node->each());
  Visit(node->enumerable());
  Visit(node->body());
}


void SCFGBuilder::VisitForOfStatement(ForOfStatement* node) {
  Visit(node->assign_iterator());
  Visit(node->next_result());
  Visit(node->result_done());
  Visit(node->assign_each());
  Visit(node->body());
}


void SCFGBuilder::VisitTryCatchStatement(TryCatchStatement* node) {

	//if(node->position() != -1)
		AddStatementToCurSBB(node, false);



	SimplifiedBasicBlock* sbb_try = scfg.cur;
	scfg.cur->control = SimplifiedBasicBlock::Control_TryCatch;

	//try block
	SimplifiedBasicBlock* sbb_try_block = createNewSBB(true);
	connectSBB(sbb_try, sbb_try_block);
  Visit(node->try_block());
  sbb_try_block = scfg.cur;

  SimplifiedBasicBlock* sbb_merge = createNewSBB(false);
  if(sbb_try_block->successors.size() == 0)
  		connectSBB(sbb_try_block, sbb_merge);

  createBranchAndVisit(sbb_try, sbb_merge, node->catch_block());

  scfg.cur = sbb_merge;

}

void SCFGBuilder::VisitTryFinallyStatement(TryFinallyStatement* node) {
	AddStatementToCurSBB(node, false);
	SimplifiedBasicBlock* sbb_try = scfg.cur;
	scfg.cur->control = SimplifiedBasicBlock::Control_TryFinally;

	SimplifiedBasicBlock* sbb_finally = createNewSBB(false);

	SimplifiedBasicBlock* sbb_try_block = createNewSBB(true);
	connectSBB(sbb_try, sbb_try_block);
	tryfin_info.push_back(sbb_finally);
  Visit(node->try_block());
  tryfin_info.pop_back();
  sbb_try_block = scfg.cur;

  scfg.cur = sbb_finally;
  if(sbb_try_block->successors.size() == 0)
  		connectSBB(sbb_try_block, sbb_finally);
  Visit(node->finally_block());

  //scfg.cur = sbb_finally;


}

void SCFGBuilder::VisitDebuggerStatement(DebuggerStatement* node) {
}


void SCFGBuilder::VisitFunctionLiteral(FunctionLiteral* node) {
}


void SCFGBuilder::VisitClassLiteral(ClassLiteral* node) {
  if (node->extends() != nullptr) {
    Visit(node->extends());
  }
  if (node->static_fields_initializer() != nullptr) {
    Visit(node->static_fields_initializer());
  }
  if (node->instance_fields_initializer_function() != nullptr) {
    Visit(node->instance_fields_initializer_function());
  }
}

void SCFGBuilder::VisitInitializeClassFieldsStatement(
    InitializeClassFieldsStatement* node) {
}

void SCFGBuilder::VisitNativeFunctionLiteral(NativeFunctionLiteral* node) {
}


void SCFGBuilder::VisitDoExpression(DoExpression* node) {
  VisitStatements(node->block()->statements());
}





void SCFGBuilder::VisitLiteral(Literal* node) {
}


void SCFGBuilder::VisitRegExpLiteral(RegExpLiteral* node) {
}


void SCFGBuilder::VisitObjectLiteral(ObjectLiteral* node) {
}


void SCFGBuilder::VisitArrayLiteral(ArrayLiteral* node) {
  if (node->values()->length() > 0) {
    for (int i = 0; i < node->values()->length(); i++) {
      Visit(node->values()->at(i));
    }
  }
}


void SCFGBuilder::VisitVariableProxy(VariableProxy* node) {
}


void SCFGBuilder::VisitAssignment(Assignment* node) {
  Visit(node->target());
  Visit(node->value());
}

void SCFGBuilder::VisitCompoundAssignment(CompoundAssignment* node) {
  VisitAssignment(node);
}

void SCFGBuilder::VisitYield(Yield* node) {
  Visit(node->expression());
}

void SCFGBuilder::VisitYieldStar(YieldStar* node) {
  Visit(node->expression());
}

void SCFGBuilder::VisitAwait(Await* node) {
  Visit(node->expression());
}

void SCFGBuilder::VisitThrow(Throw* node) {
  Visit(node->exception());
}


void SCFGBuilder::VisitProperty(Property* node) {
  Visit(node->obj());
  LhsKind property_kind = Property::GetAssignType(node);
  if (property_kind == NAMED_PROPERTY ||
      property_kind == NAMED_SUPER_PROPERTY) {
  } else {
    DCHECK(property_kind == KEYED_PROPERTY ||
           property_kind == KEYED_SUPER_PROPERTY);
    Visit(node->key());
  }
}

void SCFGBuilder::VisitResolvedProperty(ResolvedProperty* node) {
  Visit(node->object());
  Visit(node->property());
}




void SCFGBuilder::VisitCallNew(CallNew* node) {
  Visit(node->expression());
}


void SCFGBuilder::VisitCallRuntime(CallRuntime* node) {
}


void SCFGBuilder::VisitUnaryOperation(UnaryOperation* node) {
  Visit(node->expression());
}


void SCFGBuilder::VisitCountOperation(CountOperation* node) {
  Visit(node->expression());
}


void SCFGBuilder::VisitBinaryOperation(BinaryOperation* node) {
	if(node->op() == 29) { // comma seperator
		Visit(node->left());
		AddStatementToCurSBB(node->left(), true);
		Visit(node->right());
		AddStatementToCurSBB(node->right(), true);
	} else {
		Visit(node->left());
		Visit(node->right());
	}


}

void SCFGBuilder::VisitNaryOperation(NaryOperation* node) {
  Visit(node->first());
  AddStatementToCurSBB(node->first(), true);
  for (size_t i = 0; i < node->subsequent_length(); ++i) {
    Visit(node->subsequent(i));
    AddStatementToCurSBB(node->subsequent(i), true);
  }
}

void SCFGBuilder::VisitCompareOperation(CompareOperation* node) {
  Visit(node->left());
  Visit(node->right());
}


void SCFGBuilder::VisitSpread(Spread* node) {
  Visit(node->expression());
}


void SCFGBuilder::VisitEmptyParentheses(EmptyParentheses* node) {
}

void SCFGBuilder::VisitGetIterator(GetIterator* node) {
  Visit(node->iterable());
}

void SCFGBuilder::VisitGetTemplateObject(GetTemplateObject* node) {
}

void SCFGBuilder::VisitImportCallExpression(ImportCallExpression* node) {
  Visit(node->argument());
}

void SCFGBuilder::VisitThisFunction(ThisFunction* node) {
}


void SCFGBuilder::VisitSuperPropertyReference(SuperPropertyReference* node) {
}


void SCFGBuilder::VisitSuperCallReference(SuperCallReference* node) {
}


void SCFGBuilder::VisitRewritableExpression(RewritableExpression* node) {
  Visit(node->expression());
}










/* SCFGBuilder end */

}
}  // namespace v8


